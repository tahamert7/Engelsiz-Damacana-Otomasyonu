﻿namespace Engelsiz_Damacana
{


    partial class Su_tuketimi
    {
        partial class SuTuketimiDataTable
        {
        }
    }
}
